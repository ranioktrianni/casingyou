<?php
$style_supersubkat='class="form-control" id="supersubkat_id"';
echo form_dropdown("supersubkat_id",$supersubkategori,'',$style_supersubkat);
?>
