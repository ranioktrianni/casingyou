<footer>
  <div class="container">
    <div class="row">
      <div class="col-lg-2">

      <div class="col-lg-2">
        <hr><h5>Hubungi Kami</h5><hr>
        <?php foreach($kontak as $kontak){?>
          <b><?php echo $kontak->nama ?></b><br>
          +<?php echo $kontak->nohp ?><br>
          <a href="https://api.whatsapp.com/send?phone=+<?php echo $kontak->nohp ?>&text=Hi%20Gan,%20Saya%20minat%20dengan%20barangnya%20yang%20di%20website">
            <button class="btn btn-sm btn-success" type="submit" name="button">Chat via Whatsapp</button>
          </a><br><br>
        <?php } ?>
      </div>

        </div>
      </div>
    </div>
  </div>
</footer>
</body>
</html>
