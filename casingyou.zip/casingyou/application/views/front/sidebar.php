<div class="col-lg-3">
  <hr><h4>Rekomendasi Produk</h4><hr>
  <?php $this->load->view('front/modul/mod_rekomen') ?>

  <hr><h4>Blog Terbaru</h4><hr>
  <?php $this->load->view('front/modul/mod_blog') ?>

  <hr><h4>Facebook</h4><hr>
  <?php $this->load->view('front/modul/mod_facebook') ?>

  <hr><h4>Customer Service</h4><hr>
  <?php $this->load->view('front/modul/mod_cs') ?>
</div>
