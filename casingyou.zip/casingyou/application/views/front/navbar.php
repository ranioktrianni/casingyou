<div id='cssmenu' class="align-center">
  <ul>
    <li><a href='<?php echo base_url() ?>'><img src="<?php echo base_url().'assets/images/company/'.$company_data->foto.$company_data->foto_type;?>" width="100px" alt="<?php echo $company_data->company_name ?>" title="<?php echo $company_data->company_name ?>"></a></li>
    <li><a href="<?php echo base_url('produk/katalog') ?>">Arsip Produk</a></li>
    <li><a href="<?php echo base_url('konfirmasi_pembayaran') ?>">Konfirmasi Pembayaran</a></li>
    <li>
      <a href="#">
        <?php echo form_open('produk/cari_produk') ?>
          <input class="form-control mr-md-2" type="text" name="cari" size="20" placeholder="Cari Barang">
        <?php echo form_close() ?>
      </a>
    </li>
    <li><a href="<?php echo base_url('cart') ?>"><i class="fa fa-shopping-cart"></i> Keranjang (<?php echo $total_cart_navbar ?>)</a></li>
    <?php if(isset($_SESSION['identity']) && $_SESSION['usertype'] == '5'){ ?>
    <li>
      <a href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fa fa-user"></i> Hi, <?php echo $this->session->userdata('username') ?>
      </a>
      <ul>
        <li><a href="<?php echo base_url('cart/history/')?>">Riwayat Transaksi</a></li>
        <li><a href="<?php echo base_url('auth/profil') ?>">Profil Saya</a></li>
        <li><a href="<?php echo base_url('auth/edit_profil/').$this->session->userdata('user_id') ?>">Edit Profil</a></li>
        <li><a href="<?php echo base_url('auth/logout') ?>">Logout</a></li>
      </ul>
    </li>
    <?php } else { ?>
    <li><a href="<?php echo base_url('auth/register') ?>"><i class="fa fa-user"></i> Register / Login</a></li>
    <?php } ?>
  </ul>
</div>
<br>
