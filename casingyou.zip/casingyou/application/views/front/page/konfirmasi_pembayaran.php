<?php $this->load->view('front/header'); ?>
<?php $this->load->view('front/navbar'); ?>

<div class="container">
	<div class="row">
    <div class="col-lg-12">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i> Home</a></li>
      	  <li class="breadcrumb-item active">Konfirmasi Pembayaran</li>
      	</ol>
      </nav>
    </div>
		<div class="col-sm-12"><h1>Konfirmasi Pembayaran</h1>
      <hr>
      <?php echo $this->session->userdata('message') <> '' ? $this->session->userdata('message') : ''; ?>
      <?php echo form_open('konfirmasi_kirim') ?>
        <div class="form-group has-feedback"><label>No. Invoice</label>
          <input type="text" name="invoice" class="form-control" required>
        </div>
        <div class="form-group has-feedback"><label>Nama Pengirim</label>
          <input type="text" name="nama" class="form-control" required>
        </div>
        <div class="form-group has-feedback"><label>Jumlah</label>
          <input type="text" name="jumlah" class="form-control" required>
        </div>
        <div class="form-group has-feedback"><label>Bank Asal</label>
          <input type="text" name="bank_asal" class="form-control" required>
        </div>
        <div class="form-group has-feedback"><label>Bank Tujuan</label>
          <input type="text" name="bank_tujuan" class="form-control" required>
        </div>
        <button type="submit" name="button" class="btn btn-primary">Kirim</button>
      <?php echo form_close() ?>      
		</div>		
	</div>