<?php $this->load->view('front/header'); ?>
<?php $this->load->view('front/navbar'); ?>
<?php echo $script_captcha; // javascript recaptcha ?>

<div class="container">
	<div class="row">
    <div class="col-sm-12 col-lg-12">
			<nav aria-label="breadcrumb">
			  <ol class="breadcrumb">
			    <li class="breadcrumb-item"><a href="<?php echo base_url() ?>"><i class="fa fa-home"></i> Home</a></li>
					<li class="breadcrumb-item active">Login</li>
			  </ol>
			</nav>
    </div>
    <div class="col-lg-12"><h1>Login</h1>
			<hr>Belum punya akun? Silahkan Register <a href="<?php echo base_url('auth/register') ?>">disini</a><hr>
			<div class="row">
			  <div class="col-lg-12">
					<?php echo $message;?>
					<?php echo form_open("auth/login");?>
						<div class="form-group has-feedback">
							<?php echo form_input($identity) ?>
							<span class="glyphicon glyphicon-user form-control-feedback"></span>
						</div>
						<div class="form-group has-feedback">
							<?php echo form_password($password); ?>
							<span class="glyphicon glyphicon-lock form-control-feedback"></span>
						</div>
						<p><?php echo $captcha ?></p>
						<?php echo lang('login_remember_label', 'remember');?>
						<?php echo form_checkbox('remember', '1', FALSE, 'id="remember"');?>
						<div class="form-group">
							<button type="submit" name="submit" class="btn btn-primary">Login</button>
							<button type="reset" name="reset" class="btn btn-danger">Reset</button>
						</div>
					<?php echo form_close();?>
				</div>
			</div>
		</div>
	</div>
</div>