<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Konfirmasi_model extends CI_Model
{
  public $table = 'konfirmasi';
  public $id    = 'id_konfirmasi';
  public $order = 'DESC';

  function get_all()
  {
    return $this->db->get($this->table)->result();
  }

  function insert($data)
  {
    $this->db->insert($this->table, $data);
  }

}
