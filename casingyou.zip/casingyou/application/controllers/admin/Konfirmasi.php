<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Konfirmasi extends CI_Controller
{
  function __construct()
  {
    parent::__construct();
    $this->load->model('Konfirmasi_model');

    $this->data['module'] = 'Konfirmasi';

		if (!$this->ion_auth->logged_in()){redirect('admin/auth/login', 'refresh');}
  }

  public function index()
  {
    $this->data['title'] = "Data Konfirmasi";

    $this->data['konfirmasi_data'] = $this->Konfirmasi_model->get_all();

    $this->load->view('back/konfirmasi/konfirmasi_list', $this->data);
  }

}
