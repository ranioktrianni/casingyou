<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller {

	function __construct()
  {
    parent::__construct();

    /* memanggil model untuk ditampilkan pada masing2 modul */		
		$this->load->model('Cart_model');
    $this->load->model('Company_model');				
		$this->load->model('Kontak_model');
		$this->load->model('Produk_model');
		$this->load->model('Konfirmasi_model');

    /* memanggil function dari masing2 model yang akan digunakan */    
    $this->data['company_data'] 			= $this->Company_model->get_by_company();        
		$this->data['kontak'] 						= $this->Kontak_model->get_all();
		$this->data['total_cart_navbar'] 	= $this->Cart_model->total_cart_navbar();
  }

	public function company()
	{
		$this->data['title'] 							= 'Profil Toko';

    /* melakukan pengecekan data, apabila ada maka akan ditampilkan */
  	$this->data['company']            = $this->Company_model->get_by_company();

    /* memanggil view yang telah disiapkan dan passing data dari model ke view*/
		$this->load->view('front/company/body', $this->data);
	}

	public function konfirmasi_pembayaran()
	{
		$this->data['title'] 							= 'Konfirmasi Pembayaran';

		$this->load->view('front/page/konfirmasi_pembayaran', $this->data);
	}

	public function konfirmasi_kirim()
	{
		// ambil value dari masing2 form input
		$invoice 			= $this->input->post('invoice');
		$nama 				= $this->input->post('nama');
		$jumlah 			= $this->input->post('jumlah');
		$bank_asal 		= $this->input->post('bank_asal');
		$bank_tujuan 	= $this->input->post('bank_tujuan');

		$this->form_validation->set_rules('invoice', 'No. Invoice', 'trim|required');
		$this->form_validation->set_rules('nama', 'Nama Pengirim', 'trim|required');
		$this->form_validation->set_rules('jumlah', 'Jumlah', 'trim|required');
		$this->form_validation->set_rules('bank_asal', 'Bank Asal', 'trim|required');
		$this->form_validation->set_rules('bank_tujuan', 'Bank Tujuan', 'trim|required');

    // set pesan form validasi error
    $this->form_validation->set_message('required', '{field} wajib diisi');
    
    $this->form_validation->set_error_delimiters('<div class="alert alert-danger alert">', '</div>');

		if($this->form_validation->run() == FALSE)
    {			
      $this->konfirmasi_pembayaran();
    }
    else
    {	
			$data = array(
				'invoice'    	=> $this->input->post('invoice'),
				'nama'    		=> $this->input->post('nama'),
				'jumlah'    	=> $this->input->post('jumlah'),
				'bank_asal'   => $this->input->post('bank_asal'),
				'bank_tujuan' => $this->input->post('bank_tujuan'),
			);

			// eksekusi query INSERT
			$this->Konfirmasi_model->insert($data);

			$this->session->set_flashdata('message', '<div class="row"><div class="col-lg-12"><div class="alert alert-success alert">Konfirmasi pembayaran telah berhasil</div></div></div>');
			redirect(site_url('konfirmasi_pembayaran'));
    }    
	}

}
