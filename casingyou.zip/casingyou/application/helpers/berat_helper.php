<?php
function berat($string)
{
 $string  = $string / 1000;
 return $string;
}
?>
